import React from "react";

export  const CollectionContext= React.createContext();